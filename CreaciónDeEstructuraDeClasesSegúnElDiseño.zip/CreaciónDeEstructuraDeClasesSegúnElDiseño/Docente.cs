﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreaciónDeEstructuraDeClasesSegúnElDiseño
{
    internal class Docente : Empleado
    {
        public string materia {  get; set; }
    }
}
