﻿using System;

namespace CreaciónDeEstructuraDeClasesSegúnElDiseño
{
    class Program
    {

        static void Main(string[] args)
        {

            Maestro maestro = new Maestro
            {
                Nombre = "Juan",
                Edad = 35,
                Cargo = "Profesor",
                materia = "Matemáticas"
            };

            maestro.DarLaClase();
            maestro.ActividadComunitaria();





        }
    }


}