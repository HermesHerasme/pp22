﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreaciónDeEstructuraDeClasesSegúnElDiseño
{
    internal class Administrador : Docente
    {
        public void RealizandoTareaDeAdmin()
        {

            Console.WriteLine("Realizando tarea de admin");


        }
    }
}
