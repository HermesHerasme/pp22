﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreaciónDeEstructuraDeClasesSegúnElDiseño
{
    internal class ExAlumno : MiembroDeLaComunidad
    {
        public DateTime FechaDeGraduacion { get; set; }
    }
}
