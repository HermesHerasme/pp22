﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreaciónDeEstructuraDeClasesSegúnElDiseño
{
    internal class Maestro : Docente
    {
        public void DarLaClase()
        {

            Console.WriteLine("Dando la clase");

        }
    }
}
